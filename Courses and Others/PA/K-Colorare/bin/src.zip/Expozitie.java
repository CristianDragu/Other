import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Collections;
import java.util.Comparator;
import java.util.Vector;

public class Expozitie {
	
	class Nod {
		
		int numeNod;
		Vector<Integer> lista = new Vector<Integer>();
		
		public Nod(){
			numeNod = -1;
		}
		
		public Nod(int numeNod){
			this.numeNod = numeNod;
		}
		
	}
	
	class Pair{
		
		int x,y;
		
		public Pair(int x, int y){
			this.x = x;
			this.y = y;
		}
		
	}
	
	int n, numarMuchii;
	Vector<Nod> listaAdiacenta = new Vector<Nod>();
	Vector<Integer> vizitari = new Vector<Integer>();
	Vector<Pair> arce = new Vector<Pair>();
	
	public int numarArce(int poz){
		int m = arce.size(), s = 0;
		for(int i = 0; i < m; i++){
			if(arce.get(i).x == poz)
				s++;
		}
		return s;
	}
	
	public void creazaArce(){
		
		int poz, min, m;
		int[] vecini = new int[n];

		for(int i = 0; i < n; i++){
			poz = -1;
			min = 5001;
			for(int j = 0; j < n; j++){
				if(vizitari.get(j) <= min && vizitari.get(j) != 0){
					poz = j;
					min = vizitari.get(j);
				}
			}
			if(poz == -1)
				break;
			else
				if((min + numarArce(poz)) % 2 == 0) {
					m = listaAdiacenta.get(poz).lista.size();
					for(int j = 0; j < m; j++)
						vecini[j] = listaAdiacenta.get(poz).lista.get(j);
					for(int j = 0; j < m; j++){
						arce.add(new Pair(poz, vecini[j]));
						if(listaAdiacenta.get(vecini[j]).lista.removeElement((Object)poz))
							vizitari.set(vecini[j], vizitari.get(vecini[j]) - 1);
						listaAdiacenta.get(poz).lista.removeElement((Object)vecini[j]);
					}
					vizitari.set(poz, 0);
				}
				else {
					m = listaAdiacenta.get(poz).lista.size() - 1;
					for(int j = 0; j < m + 1; j++)
						vecini[j] = listaAdiacenta.get(poz).lista.get(j);
					for(int j = 0; j < m; j++){
						arce.add(new Pair(poz, vecini[j]));
						if(listaAdiacenta.get(vecini[j]).lista.removeElement((Object)poz))
							vizitari.set(vecini[j], vizitari.get(vecini[j]) - 1);
						listaAdiacenta.get(poz).lista.removeElement((Object)vecini[j]);
					}
					arce.add(new Pair(vecini[m], poz));
					listaAdiacenta.get(poz).lista.removeElement((Object)vecini[m]);
					listaAdiacenta.get(vecini[m]).lista.removeElement((Object)poz);
					vizitari.set(vecini[m], vizitari.get(vecini[m]) - 1);
					vizitari.set(poz, 0);
				}
		}
	}
	
	public static void main(String[] args) throws IOException{
		
		Expozitie o = new Expozitie();
		o.readData();
		
		o.creazaArce();
		
		o.writeData();
	}
	
	public void readData() throws IOException {
		int x1, x2;
		BufferedReader br = new BufferedReader(new FileReader("expozitie.in"));
		String linie = br.readLine();
		
		String[] slinie = linie.split(" ");
		n = Integer.parseInt(slinie[0]);
		
		for(int i = 0 ; i < n; i++) {
			listaAdiacenta.add(new Nod(i));
			vizitari.add(0);
		}
		
		while((linie = br.readLine()) != null) {
			slinie = linie.split(" ");
			
			x1 = Integer.parseInt(slinie[0]);
			x2 = Integer.parseInt(slinie[1]);
			
			
			listaAdiacenta.get(x1).lista.add(x2);
			listaAdiacenta.get(x2).lista.add(x1);
			numarMuchii ++;
			vizitari.set(x1, vizitari.get(x1) + 1);
			vizitari.set(x2, vizitari.get(x2) + 1);
		}
		
		br.close();
	}
	
	public void writeData() throws IOException {
		
		BufferedWriter bw = new BufferedWriter(new FileWriter("expozitie.out"));
		
		int m = arce.size(), s = 0, last = arce.get(0).x;
		
		Collections.sort(arce, new Comparator<Pair>() {

			@Override
			public int compare(Pair o1, Pair o2) {
				return o1.x - o2.x;
			}
		});
		
		for(int i = 0; i < m; i++){
			if(arce.get(i).x == last)
				s++;
			else if(s % 2 != 0){
				
				bw.write("Imposibil");
				bw.newLine();
				bw.close();
				
				return;
			}
			else{
				last = arce.get(i).x;
				s = 1;
			}
		}
		
		for(int i = 0; i < m; i++) {
			bw.write(arce.get(i).x + " " + arce.get(i).y);
			bw.newLine();
		}
		
		System.out.println(arce.size());
		
		bw.close();
	}
	
}
