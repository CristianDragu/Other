public class negustori {

	public static void main(String[] args){
		
	}
	
}
