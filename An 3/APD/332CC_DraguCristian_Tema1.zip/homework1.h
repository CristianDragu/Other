typedef struct images {
	int width;
	unsigned char **data;
} image;