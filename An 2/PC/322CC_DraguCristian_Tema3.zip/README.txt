Tema 3 PC

Student: Dragu Cristian
Grupa: 322 CC

Am realizat tema 3, rezolvand cerintele, cu exceptia getfile si history.

Arhiva contine 3 fisiere: server.c, client.c, helper.h.

Helper.h contine metode ajutatoarea pentru celelalte 2 surse.

Tema este implementata in C. Am pornit in rezolvarea ei de la scheletul de cod 
din laboratorul 8.

Functii implementate: infoclients, getshare, share, unshare, quit.

! NU uitati la compilarea si rularea temei sa aveti create folderele cu numele 
clientilor, date ca argumente in linia de comanda. Aceste foldere vor contine 
fisierele clientului respectiv.

! Mentionez ca in sursele temei se gasesc foarte multe comentarii care descriu 
bine modul de implementare a acesteia, si rog verificarea acestora.